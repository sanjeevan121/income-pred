def test_gen():
    a=3
    b=3
    assert a==b
    